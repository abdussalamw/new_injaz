<?php
// ملف للتحقق من المستخدمين الموجودين في قاعدة البيانات
include 'db_connection_secure.php';

echo "<h3>المستخدمون الموجودون في قاعدة البيانات:</h3>";

$result = $conn->query("SELECT employee_id, name, email, role FROM employees ORDER BY employee_id");

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>الاسم</th><th>البريد الإلكتروني</th><th>الدور</th></tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['employee_id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['role']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>لا يوجد مستخدمون في قاعدة البيانات.</p>";
}

echo "<br><br>";
echo "<h3>إنشاء مستخدم تجريبي جديد:</h3>";
echo "<p>سيتم إنشاء مستخدم بالبيانات التالية:</p>";
echo "<ul>";
echo "<li>اسم المستخدم: testuser</li>";
echo "<li>كلمة المرور: password</li>";
echo "<li>الدور: مدير</li>";
echo "</ul>";

// إنشاء مستخدم تجريبي جديد
$test_name = 'testuser';
$test_email = 'testuser@example.com';
$test_role = 'مدير';
$test_phone = '0500000000';
$test_password = password_hash('password', PASSWORD_DEFAULT);

// حذف المستخدم التجريبي إذا كان موجوداً
$conn->query("DELETE FROM employees WHERE name = 'testuser' OR email = 'testuser@example.com'");

// إنشاء المستخدم الجديد
$stmt = $conn->prepare("INSERT INTO employees (name, email, role, phone, password) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $test_name, $test_email, $test_role, $test_phone, $test_password);

if ($stmt->execute()) {
    echo "<p style='color: green;'>تم إنشاء المستخدم التجريبي بنجاح!</p>";
    echo "<p><strong>يمكنك الآن تسجيل الدخول باستخدام:</strong></p>";
    echo "<ul>";
    echo "<li>اسم المستخدم: testuser</li>";
    echo "<li>كلمة المرور: password</li>";
    echo "</ul>";
    echo "<p><a href='login.php'>انتقل إلى صفحة تسجيل الدخول</a></p>";
} else {
    echo "<p style='color: red;'>خطأ في إنشاء المستخدم: " . $conn->error . "</p>";
}
?>
